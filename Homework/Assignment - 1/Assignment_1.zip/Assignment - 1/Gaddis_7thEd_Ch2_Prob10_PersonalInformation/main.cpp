/* 
   File:   main
   Author: Cardenas, Diana
   Created on August 29, 2016, 9:41 AM
   Purpose: Display information on separate lines w/ 1 cout
 */

//System Libraries
#include <iostream>   //Input/Output objects
using namespace std;  //Name-space used in the System Library

int main(int argc, char** argv) {
    
    //Display Output
    cout<<"Diana Cardenas \n"
        <<"12345 Randall Ave, Fontana, CA 92335 \n"
        <<"(909)555-5555 \n"
        <<"Computer Science \n"
        <<endl;

    //Exit Program
    return 0;
}
